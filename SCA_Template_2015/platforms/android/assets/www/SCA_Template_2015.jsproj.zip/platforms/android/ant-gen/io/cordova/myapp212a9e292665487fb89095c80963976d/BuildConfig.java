/** Automatically generated file. DO NOT MODIFY */
package io.cordova.myapp212a9e292665487fb89095c80963976d;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}